# Git hub blog 글 업데이트

- source/_posts 폴더 안 .md 파일 작성

![Untitled](Git%20hub%20blog%20%E1%84%80%E1%85%B3%E1%86%AF%20%E1%84%8B%E1%85%A5%E1%86%B8%E1%84%83%E1%85%A6%E1%84%8B%E1%85%B5%E1%84%90%E1%85%B3%20f934d3bcb3e54b0a8efeda2ebd30a3ae/Untitled.png)

- yaml 작성

![Untitled](Git%20hub%20blog%20%E1%84%80%E1%85%B3%E1%86%AF%20%E1%84%8B%E1%85%A5%E1%86%B8%E1%84%83%E1%85%A6%E1%84%8B%E1%85%B5%E1%84%90%E1%85%B3%20f934d3bcb3e54b0a8efeda2ebd30a3ae/Untitled%201.png)

TERMINAL에

```bash
$ hexo generate
$ hexo deploy
```

차례대로 실행 하면 배포 완료